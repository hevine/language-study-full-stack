# 外语考证宝典 · 给 AI Agent 方案方的现状资料

> 配套文件：`01-schema.sql`（21 表 DDL，脱敏）、`screenshots/`（3 张实拍）
> 本文件不含任何业务数据、用户隐私与密钥；`llm_keys` 仅提供结构。

---

## 0. 一句话技术形态

**本地优先的单用户全栈 Web 应用**，不是 SaaS、不是多租户、不是桌面壳、不是小程序。

- 前端：React 18.3 + Vite 5.4，`react-router-dom` 6 **HashRouter** SPA，13 个页面，无 UI 框架、无状态库，全部视觉由一份 8,590 行手写 CSS 承担（玻璃拟态 + 主题变量）
- 后端：**Express 4.19**（不是 Nest），TypeScript 5.5 由 `tsx` 直接执行，**无编译产物**；21,500 行，`routes(18) → services(22) → repositories → db` 四层
- 数据：`better-sqlite3` **同步驱动 + 单文件**（`.data/app.db`），21 表 / 12 个迁移，无独立数据库进程
- 运行：生产单进程单端口 `:4399`（同进程既出 API 又出 `dist/web` 静态资源 + SPA fallback），默认只监听 `127.0.0.1`
- 账号：**无**。`LOCAL_USER = 'local'` 硬编码，无 JWT / Session / passport / bcrypt（全库零命中）
- 基础设施：**无 Redis、无消息队列、无 worker、无埋点**

---

## 1. P0 五项

### 1.1 数据库表结构

完整 DDL 见 `01-schema.sql`。**但比表结构更要紧的是下面这四条「不存在」**：

| 你以为有的 | 实际情况 |
|---|---|
| `users` 表 | **没有**。用户档案是 `profile` 单行表，各表 `user_id` 字段取值恒为常量 `'local'` |
| `questions` 表 | **没有统一主表**。题目分散在四处：`exam_items`(742 行，试卷题) / `ai_bank_items`(56 行，AI 生成池) / `practice_prompts`(11 行，写作口语题) / `vocab_items`(450 行，单词卡) |
| `answer_records`（逐题作答） | **没有**。只有三处近似表，且都不是逐题粒度 ↓ |
| 知识点 / 章节标签 | **没有**。只有 `section`（人读字符串）+ `section_key`（归一到 5 类） |

**作答明细的真实存储方式**（这是最关键的一条）：

- `exam_attempts` —— 整卷作答。**`answers` 是一个 JSON 文本字段**，另有 `correct` / `total` 两个汇总数。全库**仅 1 条记录且 `status='active'`（从未完整提交过）**，`correct=0, total=0`
- `practice_attempts` —— 写作/口语单次提交，**全库 1 条**（日语口语 81 分）
- `study_logs` —— 26 条，字段只有 `kind / minutes / score`，**不含任何题目标识**

**试卷表是有的**：`exam_papers` 81 份（en / ja / ko 各 27），字段含 `paper_type`（real|mock）、`sections_json`、`origin_url`、`import_file`、`import_meta`。

**标签粒度实际只有两级**：
- `exam_items.section` —— 人读的章节名，如 `Factual information`、`文脈規定`、`어휘`（语言内共 15 个）
- `exam_items.section_key` —— 归一到 5 类：`vocab / grammar / reading / listening / writing`

没有：知识点表、难度分级、tag 表、题目↔知识点关联、题干能力维度。

> **对第 7 章的直接结论：第 7 章是「新增表」，不是「改造现有表」。**
> 但不是加 1–2 张表，而是最小 5 张：`knowledge_point` / `question`（统一主表，或对三处建视图）/ `question_knowledge` / `question_attempt`（逐题）/ `diagnosis_report`。
> 其中 `question_attempt` 是**一切诊断的数据前提**，它现在不存在。

---

### 1.2 现有学情报告：截图 + 计算逻辑

截图三张（`screenshots/`）：
1. `01-dashboard-learning-stats.png` —— 首页学情总览
2. `02-practice-hub-grading.png` —— 写作·口语批改中心
3. `03-exam-paper-bank.png` —— 试卷库（81 卷 / 2000–2026 逐年）

**计算逻辑**（`server/src/services/stats.ts`，`buildStats()`）：

| 指标 | 算法 |
|---|---|
| `streak` 连续打卡 | 从最近一个有记录日期往回数连续天数 |
| `totalMinutes` 累计学习 | `study_logs.minutes` 求和 |
| `activeDays` | 有记录的去重日期数 |
| `vocabulary` | 词汇总数 / 今日到期 / 已掌握（SM-2 参数 `ease`/`interval_days` 推导） |
| `activity` | 近 14 天每日分钟数与任务数 |
| `practice` | 近 40 次写作口语的 `overall` 均分 + 趋势序列 |
| `plan.completionRate` | 已完成天 / 计划总天 |
| `plan.readiness` 达标概率 | `feasibility.probability × (0.62 + 0.38 × completionRate)`，封顶 0.97 |

**唯一的「维度化」评分，只存在于写作与口语**（`practice_attempts.dimensions`，JSON 数组）：

```json
[
  {"id":"content",      "name":"内容与切题", "weight":0.30, "score":70, "comment":"内容展开不足…"},
  {"id":"fluency",      "name":"流利与连贯", "weight":0.25, "score":90, "comment":"未检出填充词…"},
  {"id":"language",     "name":"语法与词汇", "weight":0.25, "score":92, "comment":"未检出常见语法错误…"},
  {"id":"pronunciation","name":"发音与语调", "weight":0.20, "score":74, "comment":"该维度无法仅凭文本判断…"}
]
```

这是**「输出能力评分维度」**（内容/流利/语法/发音），不是知识点诊断维度。它随考试品类变化（雅思写作 4 维、JLPT 无口语题型等，见 `domain/rubrics.ts` 376 行）。

**客观题（660 道 choice）没有任何维度数据**：既无逐题正确率，也无按 section 的正确率——因为明细只落在 JSON blob 里，且一次都没提交过。

> **对第 8 章的直接结论：诊断引擎是「从零建」，不是「升级」。**
> 唯一可直接复用的是 `dimensions` 的**输出契约范式**（`{id, name, weight, score, comment}` 加权维度 + 评语）。建议诊断报告直接沿用这个 JSON 形状，前端渲染组件可复用、用户也已习惯。
> 另外 `readiness` 是「计划可行性预测」，不是「能力诊断」，两者不要混为一谈。

---

### 1.3 题库现状

| 维度 | 实际 |
|---|---|
| 题量 | **742 题 / 81 卷**（en、ja、ko 各 27 卷，每卷 10 题 34 分钟） |
| 题型分布 | `choice` 660、`writing` 82 |
| 标签粒度 | `section` 15 个（语言内）+ `section_key` 5 类；**无知识点、无难度** |
| 解析覆盖率 | **100%（742/742 有 `explanation`）** |
| 版权来源 | **全部 `paper_type='mock'`（仿真卷），0 份真题**；`origin_url` / `import_file` 全为空；界面明确标注「仿真卷 / 非真题原卷」；真卷需经 `npm run import:exam -- --file x.json` 自行导入 |
| 附加池 | `ai_bank_items` 56 条（word 37 / sentence 14 / quiz 5），带指纹去重 |

**section 分布（节选）**：en 侧 `Vocabulary` 54 / `Conversation` 32 / `Writing` 27 / 阅读六类各 9；ja 侧 `文法形式` 54 / `文脈規定` 40 / `内容理解` 36 / `漢字読み` 28；ko 侧 `어휘` 65 / `문법` 54 / `내용 이해` 36。

> **对题库工厂的结论：合规约束强度低（无真题=无版权风险），但反过来也意味着没有内容护城河。**
> 工厂要启动只缺三样：**知识点体系**、**难度分级**、**来源溯源**（`origin_url` 字段已有但全空，等于没启用）。
> 好消息：`sections_json` + `import_meta` 已经预留了扩展位，加字段成本低。

---

### 1.4 后端技术细节

| 项 | 实际 |
|---|---|
| 框架 | **Express 4.19**（非 Nest），18 个 router |
| 认证 | **无**。无 JWT / Session / passport / bcrypt；`LOCAL_USER='local'` 常量贯穿全部 repository |
| 缓存 / 队列 | **无 Redis、无队列、无 worker**。长任务靠同步 `await` + `ai_gen_runs` 表当运行日志 |
| 输入校验 | zod（`parseBody`），统一错误中间件 + 请求 id 日志 |
| 数据驱动 | `better-sqlite3` **同步 API**，单文件，`.data` 目录 `chmod 700` |
| 部署 | 单进程，`tsx` 直跑 TS；dev 双端口（5199 反代 4399），prod 单端口 4399，仅 `127.0.0.1` |

> **对第 6 章的结论：集成方式必须是「同仓模块（in-process）」，不能是独立服务。** 三个硬约束，缺一不可推翻：
> 1. **无鉴权** —— 跨服务无法传递身份，独立服务只能裸奔或自造一套 token
> 2. **SQLite 单写者 + 同步驱动** —— 两个进程同时写会锁冲突，诊断跑批和主服务必然打架
> 3. **无队列基础设施** —— 长任务（批量诊断）只能自己实现轮询表（现有 `ai_gen_runs` 就是雏形）
>
> 如果方案里写了「独立诊断服务 + 消息队列 + Redis 缓存」，第 6 章要重写。

---

### 1.5 前端路由与页面清单

13 页，HashRouter（`web/src/App.tsx`）：

| 路由 | 页面 | 能否作挂载点 |
|---|---|---|
| `/` | Dashboard 今日概览（含学情指标） | **半可挂**：是首页 dashboard，不是独立「学情中心」；加卡片或加 tab 都行 |
| `/today` | 今日任务 | — |
| `/task/:date/:taskId` | 单任务详情 | — |
| `/plan` | 学习计划 | — |
| `/path` | 学习之路（3 阶段路线图） | — |
| `/practice` | **写作·口语批改中心** | 可挂「诊断」入口 |
| `/practice/:date/:taskId` | 单次批改详情 | — |
| `/vocab` | 词汇本（SM-2） | — |
| `/exams` | 考试中心（81 卷） | 可挂「薄弱项定向练」 |
| `/exams/:paperId/take` | 答题页 | — |
| `/exams/attempts/:attemptId` | 交卷结果 | 可挂「逐题诊断」 |
| `/setup` | 建计划向导 | — |
| `/settings` | 用户设置（模型 Key / 音色 / 主题 / 数据） | — |

> **对前端的结论：**
> - 「学情中心」——加组件即可，`/` 或 `/practice` 都能承载
> - 「教研后台」——**不存在，必须新建页面 + 新路由**；而且因为没有角色体系，后台入口只能靠「隐藏路由 / 本地配置开关」，**做不了真正的权限隔离**。这是形态限制，不是工程量问题。

---

## 2. P1 项

| 项 | 实际 |
|---|---|
| 考试品类 | 托福 iBT、JLPT（N1–N5）、TOPIK II；**3 语种 × 1 考试**，无扩展品类 |
| MAU / 日均答题量 | **不存在**。单用户本地应用；当前库内已提交试卷 **0 次**、写作口语批改 **1 次** |
| 埋点能力 | **无**。`analytics/track/events` 全库零命中。只有业务表 + 请求日志（含 request id） |
| LLM 供应商与预算 | OpenAI 兼容协议，**多线路号池**（现 5 个 key，加密存储于 `llm_keys`），可切智谱/混元/魔搭/DeepSeek；**无预算上限控制**，仅有单次 token 预算（10000）与截断重试/定向补缺 |
| 教研审核流程 | **无** |
| 报告页跳出率 | **无** |

补充两条对 Agent 有用的：未配置 Key 时自动进**演示模式**（内置题库跑全流程，可完全离线）；TTS 三档（本地 `local://edge` → 外部 openai-edge-tts → 浏览器 speechSynthesis）。

---

## 3. 附录 A 更正表：你的通用假设 vs 本项目实际

**这十行是这份资料里最该被拿去改方案的部分。**

| # | 通用假设 | 本项目实际 | 影响章节 |
|---|---|---|---|
| 1 | 有 `users` 表、多用户 | 单用户，`user_id='local'` 常量 | 6 / 7 / 8 |
| 2 | 有 `questions` 统一表 | 三处分散，无主表，需先合并或建视图 | 7 |
| 3 | 有 `answer_records` 逐题记录 | 仅 `answers` JSON blob，且从未提交过 | 7 / 8 |
| 4 | 有知识点/章节标签体系 | 只有 5 类 `section_key`，无知识点、无难度 | 7 / 8 |
| 5 | 现有学情报告是「正确率统计」 | 是**聚合量与预测概率**；无任何正确率拆解 | 8 |
| 6 | 有「教研后台」挂载点 | 无。`/settings` 是用户设置，不是教研后台 | 6 |
| 7 | 可能已有 Redis / 队列 | 无任何缓存与队列基础设施 | 6 |
| 8 | 集成可能需要认证对接 | 系统本身无认证，不存在「对接」问题 | 6 |
| 9 | 题库有真题版权约束 | **全仿真卷，0 真题**；约束反而不成立 | 题库工厂 |
| 10 | 关系库可水平扩展 | SQLite 单文件单写者，同步驱动 | 6 / 部署 |

---

## 4. 对路线图工作量估算的三点提醒

1. **最大工作项是数据基座，不是诊断算法。**
   逐题作答记录目前不存在，诊断引擎上线即「无数据可诊」。建议把「逐题落库 + 知识点标注 + 回填历史」放在第 0 阶段；否则第 8 章功能会整章空转，演示时只能拿 1 条口语记录撑场面。

2. **知识点体系是教研工作量，不是工程工作量。**
   要覆盖 3 个语种各自的考试体系：JLPT 是 `語彙/文法/読解/聴解`、TOPIK 是 `어휘/문법/읽기/듣기/쓰기`、托福是四技能 + 题型细分。三套体系不能共用一棵树。这块估时若按「建个 tag 表」算，会差一个数量级。

3. **单用户形态决定了「多角色」相关设计不成立。**
   如果 agent 设计里含教师端 / 教研角色 / 班级机构 / 审核工作流，要么砍掉，要么先给系统加账号体系——后者是独立的大工程（现有 21 张表全部无外键指向用户，迁移成本不低）。

---

## 5. 没有提供的

代码全文、真实用户数据、任何密钥，均未提供。`llm_keys` 仅导出 DDL，不含任何行。截图已确认不含个人身份信息（页面仅有「学员」默认昵称与学习统计）。

---

*如需要补充：某个具体接口的请求/响应样例、`exam_items` 单题完整 JSON、或诊断报告希望对齐的现有组件，随时可再出。*
